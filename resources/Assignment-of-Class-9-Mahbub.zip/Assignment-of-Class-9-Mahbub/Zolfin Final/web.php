<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('pages.home');
});

Route::get('/portfolio', function () {
    return view('pages.portfolio');
});

Route::get('/portfolio-details', function () {
    return view('pages.portfolio-details');
});

Route::get('/service-details', function(){
    return view('pages.service-details');
});

Route::get('/about', function(){
    return view('pages.about');
});

Route::get('/blog', function(){
    return view('pages.blog');
});

Route::get('/blog-2', function(){
    return view('pages.blog-2');
});

Route::get('/blog-details', function(){
    return view('pages.blog-details');
});

Route::get('/price', function(){
    return view('pages.price');
});

Route::get('/faq', function(){
    return view('pages.faq');
});

Route::get('/team', function(){
    return view('pages.team');
});

Route::get('/process', function(){
    return view('pages.process');
});

Route::get('/404', function(){
    return view('pages.404');
});

Route::get('/contact', function(){
    return view('pages.contact');
});
