@extends('components.common-layout')
        <!-- Header End -->

@section('content')

        <!-- Banner  -->
@include('components.contact.banner')
        <!-- Banner End -->

        <!-- Contact  -->
@include('components.contact.contact')
        <!-- Contact End -->

        <!-- Address  -->
@include('components.contact.address')
        <!-- Address End -->

@endsection