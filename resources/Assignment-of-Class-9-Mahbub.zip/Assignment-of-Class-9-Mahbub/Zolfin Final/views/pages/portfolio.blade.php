@extends('components.common-layout')
        <!-- Header End -->
        
@section('content')

        <!-- Banner  -->
@include('components.portfolio.banner')
        <!-- Banner End -->

        <!-- Portfolio  -->
@include('components.portfolio.portfolio')
        <!-- Portfolio End -->

@endsection