@extends('components.common-layout')
        <!-- Header End -->

@section('content')

        <!-- Banner  -->
@include('components.faq.banner')
        <!-- Banner End -->

        <!-- FAQ  -->
@include('components.faq.faq-1')
        <!-- FAQ End -->

@endsection