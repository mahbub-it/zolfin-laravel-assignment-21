@extends('components.common-layout')

@section('content')

        <!-- Banner  -->
@include('components.blog.banner')
        <!-- Banner End -->

        <!-- Blog Post  -->
@include('components.blog.post')
        <!-- Blog Post End -->

@endsection