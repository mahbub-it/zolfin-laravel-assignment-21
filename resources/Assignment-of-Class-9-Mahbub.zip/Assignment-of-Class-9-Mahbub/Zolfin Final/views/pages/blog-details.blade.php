@extends('components.common-layout')
        <!-- Header End -->

@section('content')

        <!-- Banner  -->
@include('components.blog.banner-3')
        <!-- Banner End -->

        <!-- Blog Post  -->
@include('components.blog.post-single')
        <!-- Blog Post End -->

@endsection