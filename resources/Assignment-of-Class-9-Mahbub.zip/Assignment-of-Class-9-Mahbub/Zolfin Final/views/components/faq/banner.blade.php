        <div class="zol-banner zol-banner--404 t-pt-150 t-pb-150">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-8 text-center">
                        <h2 class="mt-0 t-text-light">FAQ</h2>
                        <ul
                            class="t-list breadcrumbs d-flex justify-content-center align-items-center"
                        >
                            <li class="breadcrumbs__list">
                                <a
                                    href="#"
                                    class="t-link breadcrumbs__link t-link--light-alpha text-capitalize"
                                >
                                    home
                                </a>
                            </li>
                            <li class="breadcrumbs__list">
                                <a
                                    href="#"
                                    class="t-link breadcrumbs__link t-link--light-alpha text-capitalize"
                                >
                                    FAQ
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>