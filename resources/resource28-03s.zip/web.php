<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('pages.home');
});


////DATA Show Methode////
Route::get('/posts', function(){

    $all_post = DB::table('posts')->get();

    return view('pages.blog', [
        'posts' => $all_post
    ]);
});

////DATA Post Standard Methode////
Route::get('/create-post', function(){

    $title      = "Mahbub";
    $thumbnail  = "http://127.0.0.1:8000/assets/img/blog-post.png";
    $excerpt    = "This is a standard data post/insert methode";
    
    $insert_post = DB::insert("INSERT INTO posts (title, thumbnail, excerpt) VALUES (?, ?, ?)", [$title, $thumbnail, $excerpt]);

    if($insert_post){
        return "post has been inserted";
    }
});

////DATA Update Standard Methode////
Route::get('/update-post', function(){

    $update_post = DB::table("posts")
    // ->where('id', '<>', '8') //All will be chenge without id 8
    ->where('id', '=', '8') // Or same equel ('id', '8')
    ->update(['thumbnail'=> 'https://www.dreamwebdev.com/wp-content/uploads/2021/08/Shah-Mahbubur-Rahman-Webdev.jpg']);

});

////DATA Delete ////
// Route::get('/delete-post', function(){

//     $delete_post = DB::table("posts")
//     ->where('id', '>', '9')
//     ->where('id', '<', '11')
//     ->delete();

// });

////Or Another Way to DATA Delete ////
Route::get('/delete-post', function(){

    $post_id = 9;

    DB::table("posts")
    ->where('id', $post_id)
    ->delete();

});



// Route::get('/test', function(){

//     $all_posts = DB::table('posts')->get();

//     foreach( $all_posts as $single_post ){

//         echo "<p><img src='{$single_post->thumbnail}' /> </p> ";

//         echo "<h1>'{$single_post->title}'</h1>";

//         echo "<p>'{$single_post->excerpt}'</p>";

//         }
//     });
/////////////////////////////////////////

    // echo '<pre>';
    // print_r( DB::table('posts')->get() );
    // echo '</pre>';
// });






// Route::get('/portfolio', function () {
//     return view('pages.portfolio');
// });

// Route::get('/portfolio-details', function () {
//     return view('pages.portfolio-details');
// });

// Route::get('/service-details', function(){
//     return view('pages.service-details');
// });

// Route::get('/about', function(){
//     return view('pages.about');
// });



// Route::get('/blog-2', function(){
//     return view('pages.blog-2');
// });

// Route::get('/blog-details', function(){
//     return view('pages.blog-details');
// });

// Route::get('/price', function(){
//     return view('pages.price');
// });

// Route::get('/faq', function(){
//     return view('pages.faq');
// });

// Route::get('/team', function(){
//     return view('pages.team');
// });

// Route::get('/process', function(){
//     return view('pages.process');
// });

// Route::get('/404', function(){
//     return view('pages.404');
// });

// Route::get('/contact', function(){
//     return view('pages.contact');
// });
