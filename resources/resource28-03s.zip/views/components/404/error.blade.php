        <div class="t-pb-120">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <img src="assets/img/404.png" alt="zolfin" class="img-fluid mx-auto">
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 text-center">
                        <h2 class="t-mt-50 text-capitalize">
                            Oops.... Page Not Found
                        </h2>
                        <a href="#" class="t-link bttn bttn-lg bttn-round bttn-alpha text-capitalize t-mt-50">
                            get started
                        </a>
                    </div>
                </div>
            </div>
        </div>