<h1 style="text-align: center;">{!!"<u style='color: blue;'>Blade Template Basic System</u>"!!}</h1>

<h2>2+3 = <?php echo 2+3; ?></h2>

<h2>2+3 = {{ 2+3 }}</h2>

<h2>Underline= {!! "<u style='color: red'>This is underline area</u>" !!}</h2>