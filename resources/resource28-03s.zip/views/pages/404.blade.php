@extends('components.common-layout')
        <!-- Header End -->

@section('content')

        <!-- Banner  -->
@include('components.404.banner')
        <!-- Banner End -->

        <!-- Error  -->
@include('components.404.error')
        <!-- Error End -->

@endsection