@extends('components.common-layout')
        <!-- Header End -->

@section('content')

        <!-- Banner  -->
@include('components.process.banner')
        <!-- Banner End -->
        
        <!-- Work Process  -->
@include('components.process.work-process')
        <!-- Work Process End -->

@endsection