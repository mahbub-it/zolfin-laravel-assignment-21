@extends('components.common-layout')
        <!-- Header End -->

@section('content')

        <!-- Banner  -->
@include('components.services.banner')
        <!-- Banner End -->

        <!-- Service Details End -->
@include('components.services.service-details')
        <!-- Service Details End -->

@endsection
