@extends('components.common-layout')
        <!-- Header End -->

@section('content')

        <!-- Banner  -->
@include('components.blog.banner-2')
        <!-- Banner End -->

        <!-- Blog Post  -->
@include('components.blog.post-sidebar')
        <!-- Blog Post End -->

@endsection