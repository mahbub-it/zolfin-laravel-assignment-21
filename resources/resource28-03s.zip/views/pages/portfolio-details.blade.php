@extends('components.common-layout')
        <!-- Header End -->
        
@section('content')

        <!-- Banner  -->
@include('components.portfolio.banner')
        <!-- Banner End -->

        <!-- Portfolio  Details-->
@include('components.portfolio.portfolio-details')
        <!-- Portfolio End -->

@endsection